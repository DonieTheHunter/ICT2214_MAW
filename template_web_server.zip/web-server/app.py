from flask import Flask, request, jsonify, render_template
import os
import hashlib
from werkzeug.middleware.proxy_fix import ProxyFix

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["GET","POST"])
def upload_file():
    if "uploaded_file" not in request.files:
        return "No file part", 400

    file = request.files["uploaded_file"]

    if file.filename == "":
        return "No selected file", 400

    file_path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
    file.save(file_path)

    # Calculate hash (useful for security testing)
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        sha256.update(f.read())

    return jsonify({
        "status": "success",
        "filename": file.filename,
        "size_bytes": os.path.getsize(file_path),
        "sha256": sha256.hexdigest(),
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, ssl_context=("/etc/https_cert/web.crt", "/etc/https_cert/web.key"), threaded=True, debug=True)